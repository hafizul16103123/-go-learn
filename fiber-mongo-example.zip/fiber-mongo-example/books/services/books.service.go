package bookService

import (
	"context"

	"github.com/bmdavis419/fiber-mongo-example/books/dtos"
	"github.com/bmdavis419/fiber-mongo-example/common"
	"github.com/bmdavis419/fiber-mongo-example/models"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/bson/primitive"
	"go.mongodb.org/mongo-driver/mongo"
)

type BookService struct {
	dbCollection *mongo.Collection
}

func NewBookService() *BookService {
	return &BookService{
		dbCollection: common.GetDBCollection("books"),
	}
}

func (s *BookService) GetAllBooks(ctx context.Context) ([]models.Book, error) {
	books := make([]models.Book, 0)
	cursor, err := s.dbCollection.Find(ctx, bson.M{})
	if err != nil {
		return nil, err
	}

	// Iterate over the cursor
	for cursor.Next(ctx) {
		book := models.Book{}
		err := cursor.Decode(&book)
		if err != nil {
			return nil, err
		}
		books = append(books, book)
	}

	return books, nil
}

func (s *BookService) GetBookByID(ctx context.Context, id string) (*models.Book, error) {
	objectId, err := primitive.ObjectIDFromHex(id)
	if err != nil {
		return nil, err
	}

	book := models.Book{}
	err = s.dbCollection.FindOne(ctx, bson.M{"_id": objectId}).Decode(&book)
	if err != nil {
		return nil, err
	}

	return &book, nil
}

func (s *BookService) CreateBook(ctx context.Context, dto *dtos.CreateDTO) (*mongo.InsertOneResult, error) {
	book := models.Book{
		Title:  dto.Title,
		Author: dto.Author,
		Year:   dto.Year,
	}
	result, err := s.dbCollection.InsertOne(ctx, book)
	if err != nil {
		return nil, err
	}
	return result, nil
}

func (s *BookService) UpdateBook(ctx context.Context, id string, dto *dtos.UpdateDTO) (*mongo.UpdateResult, error) {
	objectId, err := primitive.ObjectIDFromHex(id)
	if err != nil {
		return nil, err
	}

	updateData := bson.M{}
	if dto.Title != "" {
		updateData["title"] = dto.Title
	}
	if dto.Author != "" {
		updateData["author"] = dto.Author
	}
	if dto.Year != "" {
		updateData["year"] = dto.Year
	}

	result, err := s.dbCollection.UpdateOne(ctx, bson.M{"_id": objectId}, bson.M{"$set": updateData})
	if err != nil {
		return nil, err
	}

	return result, nil
}

func (s *BookService) DeleteBook(ctx context.Context, id string) (*mongo.DeleteResult, error) {
	objectId, err := primitive.ObjectIDFromHex(id)
	if err != nil {
		return nil, err
	}

	result, err := s.dbCollection.DeleteOne(ctx, bson.M{"_id": objectId})
	if err != nil {
		return nil, err
	}

	return result, nil
}